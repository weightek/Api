﻿namespace WebApplication1.Models
{
    public class Datas
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string email { get; set; }

        public string roll { get; set; }



    }
}
